package com.cg.cart.service;

import java.util.List;

import com.cg.cart.bean.Product;
import com.cg.cart.exception.ProductException;

/***
*Author: Shivam Chaudhary
*Date of creation: 30/07/2019
*Interface name: IproductService 
*purpose; To declare the methods used by service layer
*/

public interface IProductService {
	
	public void createProduct(Product pro)throws ProductException;
	public void updateProduct(String id,Product pro)throws ProductException;
	public void deleteProduct(String id)throws ProductException;
	public List<Product> viewProduct()throws ProductException;
	public Product findProductById(String id)throws ProductException;

}
