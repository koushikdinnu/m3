package com.cg.cart.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.cart.bean.Product;
/***
*Author: Shivam Chaudhary
*Date of creation: 30/07/2019
*Interface name: IProductRepo
*purpose: 
*/
@Repository
public interface IProductRepo extends JpaRepository<Product, String> {

}
