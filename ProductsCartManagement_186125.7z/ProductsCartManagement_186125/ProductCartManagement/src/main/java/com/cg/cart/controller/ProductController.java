package com.cg.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cart.bean.Product;
import com.cg.cart.exception.ProductException;
import com.cg.cart.service.IProductService;
//This is the controller Class
@RestController
public class ProductController {
	@Autowired
	IProductService productservice;
	
	@RequestMapping(value = "/products")
	public List<Product> viewProduct()throws ProductException
	{
		return productservice.viewProduct();
	}
	
	@RequestMapping(value = "/products/{id}",method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteSession(@PathVariable String id)throws ProductException
	{
		productservice.deleteProduct(id);
		return new ResponseEntity<String>("Product with Id: "+id+" deleted",HttpStatus.OK);
	}
	
	@RequestMapping(value = "/products/{id}",method = RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(@PathVariable String id,@RequestBody Product pro)throws ProductException
	{
		productservice.updateProduct(id,pro);
		return new ResponseEntity<String>("Product with Id: "+id+" updated",HttpStatus.OK);
	}
	
	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public List<Product> createProduct(@RequestBody Product pro)throws ProductException{
		productservice.createProduct(pro);
		return productservice.viewProduct();
	}
	
	@RequestMapping(value = "/products/{id}", method = RequestMethod.GET)
	public Product findProductById(@PathVariable String id)throws ProductException{
		return productservice.findProductById(id);
	}

}
