package com.cg.cart.controller;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.cart.exception.ProductException;

@ControllerAdvice
public class ProductExceptionHandler {
	@ExceptionHandler(ProductException.class)
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.OK);

	}

}
