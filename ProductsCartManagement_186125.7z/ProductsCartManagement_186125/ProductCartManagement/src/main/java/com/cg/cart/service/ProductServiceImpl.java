package com.cg.cart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cart.bean.Product;
import com.cg.cart.dao.IProductRepo;
import com.cg.cart.exception.ProductException;


/***
*Author: Shivam Chaudhary
*Date of creation: 30/07/2019
*Class name: ProductServiceImpl
*purpose; To implement the methods declared by service layer interface
*/
@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo productrepo;
	
	/***
	*Author: Shivam Chaudhary
	*Date of creation: 30/07/2019
	*method name: createProduct
	*Parameters: Product type Object
    *return value: no return type
	*purpose: To create a new product
	*/
	@Override
	public void createProduct(Product pro)throws ProductException {
		productrepo.save(pro);
		
	}
	/***
	*Author: Shivam Chaudhary
	*Date of creation: 30/07/2019
	*method name: createProduct
	*Parameters: Id of product and Product type Object
    *return value: no return type
	*purpose: To update a existing product with given id
	*/
	@Override
	public void updateProduct(String id,Product pro)throws ProductException {
		 Optional<Product> optionalSession = productrepo.findById(id);
		 try {
		 if(optionalSession.isPresent())
		 {
		productrepo.save(pro);
		 }
		 else {
			 throw new ProductException("Product Id not present!");
		 }
	}
		catch(Exception ex)
		{
			throw new ProductException("Product Id not present!");
		}
		
	}
	/***
	*Author: Shivam Chaudhary
	*Date of creation: 30/07/2019
	*method name: deleteProduct
	*Parameters: id of product
    *return value: no return type
	*purpose: To delete a existing product with given id. It will give exception when id is not present.
	*/
	@Override
	public void deleteProduct(String id)throws ProductException {
		try {
			 Optional<Product> optionalSession = productrepo.findById(id);
			 if(optionalSession.isPresent())
			 {
			productrepo.deleteById(id);
			 }
			 else {
				 throw new ProductException("Product Id not present!");
			 }
			}
			catch(Exception ex)
			{
				throw new ProductException("Product Id not present!");
			}
		
	}
	/***
	*Author: Shivam Chaudhary
	*Date of creation: 30/07/2019
	*method name: viewProduct
	*Parameters: nil
    *return value: List of Product Type
	*purpose: To display all the products
	*/
	@Override
	public List<Product> viewProduct()throws ProductException {
		return productrepo.findAll();
	}
	/***
	*Author: Shivam Chaudhary
	*Date of creation: 30/07/2019
	*method name: findProductById
	*Parameters: Id of Product
    *return value: Product Type Object
	*purpose: To search for an existing product.  It will give exception when id is not present.
	*/
	@Override
	public Product findProductById(String id)throws ProductException {
		try {
			 Optional<Product> optionalSession = productrepo.findById(id);
			 if(optionalSession.isPresent())
			 {
				 return productrepo.findById(id).get();
			 }
			 else {
				 throw new ProductException("Product Id not present!");
			 }
			}
			catch(Exception ex)
			{
				throw new ProductException("Product Id not present!");
			}
	}

}
